package com.avega.training.model;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "role")
public class Role {
	
	@Id
	private String roleId;
	private String roleName;
	@ManyToMany(mappedBy = "roles", fetch = FetchType.EAGER)
	private List<Employee> employees;
	public Role() {
		
	}
	
	public Role(String roleId, String roleName, List<Employee> employees) {
		super();
		this.roleId = roleId;
		this.roleName = roleName;
		this.employees = employees;
	}

	public String getRoleId() {
		return roleId;
	}

	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public List<Employee> getEmployees() {
		return employees;
	}

	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}
	
}
