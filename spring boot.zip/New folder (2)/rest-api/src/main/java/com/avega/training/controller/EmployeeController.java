package com.avega.training.controller;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.avega.training.model.Employee;
import com.avega.training.property.LocalDateProperty;
import com.avega.training.service.EmployeeService;

@Controller
public class EmployeeController {
	
	@Autowired
	EmployeeService dao;
	
	@InitBinder
	public void employeeBinder(WebDataBinder webDataBinder) {
		webDataBinder.registerCustomEditor(LocalDate.class, "doj", new LocalDateProperty());
	}
	
	@RequestMapping("/employeelist")
	public String employeelist(Model model) {
		List<Employee> list = dao.findAllEmployee();
		model.addAttribute("list", list);
		return "employeelist";
	}
	
	@RequestMapping("/employeeform")    
    public String showform(Model model){    
        model.addAttribute("command", new Employee());  
        return "employeeform";   
    }
	
	@RequestMapping(value="/save",method = RequestMethod.POST)    
    public String save(@ModelAttribute("emp") Employee emp){    
        dao.addEmployee(emp);   
        return "redirect:/employeelist";
    }
	
	@RequestMapping(value="/employeeeditform")    
    public String edit(@RequestParam (required=false,name="employeeId")String employeeId, Model model){  
        Optional<Employee> emp=dao.findByEmployeeId(employeeId);  
        if(emp.isPresent()) {
        	Employee e = emp.get();
        	model.addAttribute("command", e); 
        }
        return "employeeeditform";    
    }
	
	@RequestMapping(value="/editsave",method = RequestMethod.POST)    
    public String editsave(@ModelAttribute("emp") Employee emp){  
        dao.updateEmployee(emp);
        return "redirect:/employeelist";    
    }
	
	@RequestMapping(value="/deleteemp/{employeeId}",method = RequestMethod.GET)    
    public String delete(@PathVariable String employeeId){  
		Optional<Employee> emp = dao.findByEmployeeId(employeeId);
        if(emp.isPresent())
        	dao.deleteEmployee(emp.get());
        return "redirect:/employeelist";    
    }  
}
