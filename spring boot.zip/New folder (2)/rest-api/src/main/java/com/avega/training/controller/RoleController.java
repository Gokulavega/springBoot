package com.avega.training.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.avega.training.model.Employee;
import com.avega.training.model.Role;
import com.avega.training.service.RoleService;

@Controller
public class RoleController {
	
	@Autowired
	RoleService dao;
	
	@RequestMapping("/rolelist")
	public String rolelist(Model model) {
		List<Role> list = dao.findAllRole();
		model.addAttribute("list", list);
		return "rolelist";
	}
	
	@RequestMapping("/roleform")    
    public String showform(Model model){    
        model.addAttribute("command", new Employee());  
        return "roleform";   
    }
	
	@RequestMapping(value="/saverole",method = RequestMethod.POST)    
    public String save(@ModelAttribute("role") Role role){    
        dao.addRole(role);  
        return "redirect:/rolelist";
    }
	
	@RequestMapping(value="/roleeditform")    
    public String edit(@RequestParam (required=false,name="roleId")String roleId, Model model){  
        Optional<Role> role=dao.findById(roleId);  
        if(role.isPresent()) {
        	Role e = role.get();
        	model.addAttribute("command", e); 
        }
        return "roleeditform";    
    }
	
	@RequestMapping(value="/editsaverole",method = RequestMethod.POST)    
    public String editsave(@ModelAttribute("emp") Role role){  
        dao.updateRole(role);
        return "redirect:/rolelist";    
    }
	
	@RequestMapping(value="/deleterole/{roleId}",method = RequestMethod.GET)    
    public String delete(@PathVariable String roleId){  
		Optional<Role> role = dao.findById(roleId);
        if(role.isPresent())
        	dao.deleteRole(role.get());
        return "redirect:/rolelist";    
    }  
}
