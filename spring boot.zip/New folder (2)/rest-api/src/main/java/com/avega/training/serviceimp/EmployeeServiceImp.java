package com.avega.training.serviceimp;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.avega.training.dao.EmployeeDao;
import com.avega.training.dao.RoleDao;
import com.avega.training.model.Employee;
import com.avega.training.model.Role;
import com.avega.training.service.EmployeeService;

@Service
public class EmployeeServiceImp implements EmployeeService{
	
	
	EmployeeDao dao;
	RoleDao roleDao;
	
	@Autowired
	public EmployeeServiceImp(EmployeeDao dao, RoleDao roleDao) {
		this.dao = dao;
		this.roleDao = roleDao;
	}

	@Override
	public List<Employee> findAllEmployee() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}

	@Override
	public Optional<Employee> findByEmployeeId(String employeeId) {
		// TODO Auto-generated method stub
		return dao.findById(employeeId);
	}

	@Override
	public Employee addEmployee(Employee employee) {
		return dao.save(employee);
	}

	@Override
	public void updateEmployee(Employee employee) {
		
		Optional<Employee> emp = dao.findById(employee.getEmployeeId());
		if(emp.isPresent()) {
			emp.get().setName(employee.getName());
			emp.get().setDesignation(employee.getDesignation());
			emp.get().setDoj(employee.getDoj());
			addEmployee(emp.get());
		}
	}

	@Override
	public void deleteEmployee(Employee employee) {
		dao.delete(employee);
	}

	@Override
	public void allocationRoleToEmployee(String roleId, String employeeId) {
		Optional<Employee> emp = dao.findById(employeeId);
		if(emp.isPresent()) {
			Employee employee = emp.get();
			Optional<Role> rol = roleDao.findById(roleId);
			if(rol.isPresent()) {
				Role role = rol.get();
				List<Role> roles = employee.getRoles();
				roles.add(role);
				employee.setRoles(roles);
				dao.save(employee);
			}
		}
	}

	
}
