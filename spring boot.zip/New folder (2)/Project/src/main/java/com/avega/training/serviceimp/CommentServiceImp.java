package com.avega.training.serviceimp;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.avega.training.dao.CommentDao;
import com.avega.training.model.Comment;
import com.avega.training.service.CommentService;

@Service
public class CommentServiceImp implements CommentService{
	
	CommentDao dao;

	public CommentServiceImp(CommentDao dao) {
		this.dao = dao;
	}

	@Override
	public List<Comment> findAllComment() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}

	@Override
	public Optional<Comment> findById(String Id) {
		// TODO Auto-generated method stub
		return dao.findById(Id);
	}

	@Override
	public Comment addComment(Comment comment) {
		// TODO Auto-generated method stub
		return dao.save(comment);
	}

	@Override
	public void updateComment(Comment comment) {
		
		Optional<Comment> ncomment = dao.findById(comment.getCommentId());
		if(ncomment.isPresent()) {
			ncomment.get().setBlog(comment.getBlog());
			ncomment.get().setBlogId(comment.getBlogId());
			ncomment.get().setComment(comment.getComment());
			ncomment.get().setDate_created(comment.getDate_created());
			ncomment.get().setUserId(comment.getUserId());
			addComment(ncomment.get());
		}
	}

	@Override
	public void deleteComment(Comment comment) {
		
		dao.delete(comment);
	}

}
