package com.avega.training.service;

import java.util.List;
import java.util.Optional;

import com.avega.training.model.User_Profile;

public interface User_ProfileService {
	
	List<User_Profile> findAllUserProfile();
	
	Optional<User_Profile> findById(String id);
	
	User_Profile addUserProfile(User_Profile user_Profile);
	
	void updateUserProfile(User_Profile user_Profile);
	
	void deleteUserProfile(User_Profile user_Profile);
	
}
