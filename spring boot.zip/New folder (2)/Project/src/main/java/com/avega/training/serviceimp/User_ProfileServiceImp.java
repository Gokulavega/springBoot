package com.avega.training.serviceimp;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.avega.training.dao.User_ProfileDao;
import com.avega.training.model.User_Profile;
import com.avega.training.service.User_ProfileService;

@Service
public class User_ProfileServiceImp implements User_ProfileService{
	
	User_ProfileDao dao;
	
	@Autowired
	public User_ProfileServiceImp(User_ProfileDao dao) {
		this.dao = dao;
	}

	@Override
	public List<User_Profile> findAllUserProfile() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}

	@Override
	public Optional<User_Profile> findById(String Id) {
		// TODO Auto-generated method stub
		return dao.findById(Id);
	}

	@Override
	public User_Profile addUserProfile(User_Profile user_Profile) {
		// TODO Auto-generated method stub
		return dao.save(user_Profile);
	}

	@Override
	public void updateUserProfile(User_Profile user_Profile) {
		
		Optional<User_Profile> user = dao.findById(user_Profile.getId());
		if(user.isPresent()) {
			user.get().setName(user_Profile.getName());
			user.get().setFacebook_profile(user_Profile.getFacebook_profile());
			user.get().setBlog(user_Profile.getBlog());
			addUserProfile(user.get());
		}
	}

	@Override
	public void deleteUserProfile(User_Profile user_Profile) {
		
		dao.delete(user_Profile);
	}

}
