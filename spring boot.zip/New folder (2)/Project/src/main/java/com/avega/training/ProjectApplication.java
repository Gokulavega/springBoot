package com.avega.training;

import java.time.LocalDate;
import java.util.Optional;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.avega.training.model.Blog;
import com.avega.training.model.User_Profile;
import com.avega.training.service.BlogService;
import com.avega.training.service.CommentService;
import com.avega.training.service.LikeService;
import com.avega.training.service.User_ProfileService;
import com.avega.training.serviceimp.BlogServiceImp;
import com.avega.training.serviceimp.CommentServiceImp;
import com.avega.training.serviceimp.LikeServiceImp;
import com.avega.training.serviceimp.User_ProfileServiceImp;

@SpringBootApplication
public class ProjectApplication {

	public static void main(String[] args) {
		ApplicationContext ctn = SpringApplication.run(ProjectApplication.class, args);
		
		User_ProfileService user = ctn.getBean(User_ProfileServiceImp.class);
		BlogService blog = ctn.getBean(BlogServiceImp.class);
		LikeService like = ctn.getBean(LikeServiceImp.class);
		CommentService comment = ctn.getBean(CommentServiceImp.class);
		
		user.addUserProfile(new User_Profile("u1","a","a facebook",null));
		
		Optional<User_Profile> u = user.findById("u1");
		if(u.isPresent())
			blog.addBlog(new Blog("b1","u001","enginer","wimdvivmir",LocalDate.of(2019, 03, 13),u.get(),null,null));
		
	}

}
