package com.avega.training.model;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "User_Profile")
public class User_Profile {
	
	@Id
	private String id;
	private String name;
	private String facebook_profile;
	@OneToMany(mappedBy = "user_Profile")
	private List<Blog> blog;
	public User_Profile() {
		
	}
	public User_Profile(String id, String name, String facebook_profile, List<Blog> blog) {
		super();
		this.id = id;
		this.name = name;
		this.facebook_profile = facebook_profile;
		this.blog = blog;
	}
	@Override
	public String toString() {
		return "User_Profile [id=" + id + ", name=" + name + ", facebook_profile=" + facebook_profile + ", blog=" + blog
				+ "]";
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getFacebook_profile() {
		return facebook_profile;
	}
	public void setFacebook_profile(String facebook_profile) {
		this.facebook_profile = facebook_profile;
	}
	public List<Blog> getBlog() {
		return blog;
	}
	public void setBlog(List<Blog> blog) {
		this.blog = blog;
	}
	
	
}
