package com.avega.training.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "like")
public class Like {
	
	@Id
	private String likeId;
	private String blogId;
	private String userId;
	@ManyToOne
	@JoinColumn(name = "id")
	private Blog blog;
	public Like() {
		
	}
	public Like(String likeId, String blogId, String userId, Blog blog) {
		super();
		this.likeId = likeId;
		this.blogId = blogId;
		this.userId = userId;
		this.blog = blog;
	}
	public String getLikeId() {
		return likeId;
	}
	public void setLikeId(String likeId) {
		this.likeId = likeId;
	}
	public String getBlogId() {
		return blogId;
	}
	public void setBlogId(String blogId) {
		this.blogId = blogId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public Blog getBlog() {
		return blog;
	}
	public void setBlog(Blog blog) {
		this.blog = blog;
	}
	@Override
	public String toString() {
		return "Like [likeId=" + likeId + ", blogId=" + blogId + ", userId=" + userId + ", blog=" + blog + "]";
	}
}
