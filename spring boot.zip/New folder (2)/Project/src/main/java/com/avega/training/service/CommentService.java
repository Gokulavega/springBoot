package com.avega.training.service;

import java.util.List;
import java.util.Optional;

import com.avega.training.model.Comment;

public interface CommentService {
	
	List<Comment> findAllComment();
	
	Optional<Comment> findById(String Id);
	
	Comment addComment(Comment comment);
	
	void updateComment(Comment comment);
	
	void deleteComment(Comment comment);
	
}
