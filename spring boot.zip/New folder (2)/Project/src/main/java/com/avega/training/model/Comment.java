package com.avega.training.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "comment")
public class Comment {
	
	@Id
	private String commentId;
	private String blogId;
	private String userId;
	private String comment;
	private LocalDate date_created;
	@ManyToOne
	@JoinColumn(name = "id")
	private Blog blog;
	public Comment() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Comment(String commentId, String blogId, String userId, String comment, LocalDate date_created, Blog blog) {
		super();
		this.commentId = commentId;
		this.blogId = blogId;
		this.userId = userId;
		this.comment = comment;
		this.date_created = date_created;
		this.blog = blog;
	}
	public String getCommentId() {
		return commentId;
	}
	public void setCommentId(String commentId) {
		this.commentId = commentId;
	}
	public String getBlogId() {
		return blogId;
	}
	public void setBlogId(String blogId) {
		this.blogId = blogId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public LocalDate getDate_created() {
		return date_created;
	}
	public void setDate_created(LocalDate date_created) {
		this.date_created = date_created;
	}
	public Blog getBlog() {
		return blog;
	}
	public void setBlog(Blog blog) {
		this.blog = blog;
	}
	@Override
	public String toString() {
		return "Comment [commentId=" + commentId + ", blogId=" + blogId + ", userId=" + userId + ", comment=" + comment
				+ ", date_created=" + date_created + ", blog=" + blog + "]";
	}
}
