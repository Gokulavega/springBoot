package com.avega.training.service;

import java.util.List;
import java.util.Optional;

import com.avega.training.model.Blog;

public interface BlogService {
	
	List<Blog> findAllBlog();
	
	Optional<Blog> findById(String Id);
	
	Blog addBlog(Blog blog);
	
	void updateBlog(Blog blog);
	
	void deleteBlog(Blog blog);
	
}
