package com.avega.training.service;

import java.util.List;
import java.util.Optional;

import com.avega.training.model.Like;

public interface LikeService {
	
	List<Like> findAllLike();
	
	Optional<Like> findById(String Id);
	
	Like addLike(Like like);
	
	void updateLike(Like like);
	
	void deleteLike(Like like);
	
}
