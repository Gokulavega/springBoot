package com.avega.training.serviceimp;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.avega.training.dao.Blogdao;
import com.avega.training.model.Blog;
import com.avega.training.service.BlogService;

@Service
public class BlogServiceImp implements BlogService{
	
	Blogdao dao;

	@Autowired
	public BlogServiceImp(Blogdao dao) {
		this.dao = dao;
	}

	@Override
	public List<Blog> findAllBlog() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}

	@Override
	public Optional<Blog> findById(String Id) {
		// TODO Auto-generated method stub
		return dao.findById(Id);
	}

	@Override
	public Blog addBlog(Blog blog) {
		// TODO Auto-generated method stub
		return dao.save(blog);
	}

	@Override
	public void updateBlog(Blog blog) {
		
		Optional<Blog> nblog = dao.findById(blog.getBlog_id());
		if(nblog.isPresent()) {
			nblog.get().setBlog(blog.getBlog());
			nblog.get().setBlog_title(blog.getBlog_title());
			nblog.get().setComment(blog.getComment());
			nblog.get().setDate_created(blog.getDate_created());
			nblog.get().setLike(blog.getLike());
			nblog.get().setUser_id(blog.getUser_id());
			nblog.get().setUser_Profile(blog.getUser_Profile());
			addBlog(nblog.get());
		}
	}

	@Override
	public void deleteBlog(Blog blog) {
		
		dao.delete(blog);
	}

}
