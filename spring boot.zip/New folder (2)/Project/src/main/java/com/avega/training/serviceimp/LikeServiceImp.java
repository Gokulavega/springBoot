package com.avega.training.serviceimp;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.avega.training.dao.LikeDao;
import com.avega.training.model.Like;
import com.avega.training.service.LikeService;

@Service
public class LikeServiceImp implements LikeService{
	
	LikeDao dao;

	public LikeServiceImp(LikeDao dao) {
		this.dao = dao;
	}

	@Override
	public List<Like> findAllLike() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}

	@Override
	public Optional<Like> findById(String Id) {
		// TODO Auto-generated method stub
		return dao.findById(Id);
	}

	@Override
	public Like addLike(Like like) {
		// TODO Auto-generated method stub
		return dao.save(like);
	}

	@Override
	public void updateLike(Like like) {
		
		Optional<Like> nlike = dao.findById(like.getLikeId());
		if(nlike.isPresent()) {
			nlike.get().setBlog(like.getBlog());
			nlike.get().setBlogId(like.getBlogId());
			nlike.get().setUserId(like.getUserId());
			addLike(nlike.get());
		}
	}

	@Override
	public void deleteLike(Like like) {
		
		dao.delete(like);
	}

}
