package com.avega.training.model;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "blog")
public class Blog {
	
	@Id
	private String blog_id;
	private String user_id;
	private String blog_title;
	private String blog;
	private LocalDate date_created;
	
	@ManyToOne
	@JoinColumn(name = "user_Profile")
	private User_Profile user_Profile;
	
	@OneToMany(mappedBy = "blog")
	private List<Like> like;
	
	@OneToMany(mappedBy = "blog")
	private List<Comment> comment;

	public Blog() {
		
	}

	public Blog(String blog_id, String user_id, String blog_title, String blog, LocalDate date_created,
			User_Profile user_Profile, List<Like> like, List<Comment> comment) {
		super();
		this.blog_id = blog_id;
		this.user_id = user_id;
		this.blog_title = blog_title;
		this.blog = blog;
		this.date_created = date_created;
		this.user_Profile = user_Profile;
		this.like = like;
		this.comment = comment;
	}

	public String getBlog_id() {
		return blog_id;
	}

	public void setBlog_id(String blog_id) {
		this.blog_id = blog_id;
	}

	public String getUser_id() {
		return user_id;
	}

	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}

	public String getBlog_title() {
		return blog_title;
	}

	public void setBlog_title(String blog_title) {
		this.blog_title = blog_title;
	}

	public String getBlog() {
		return blog;
	}

	public void setBlog(String blog) {
		this.blog = blog;
	}

	public LocalDate getDate_created() {
		return date_created;
	}

	public void setDate_created(LocalDate date_created) {
		this.date_created = date_created;
	}

	public User_Profile getUser_Profile() {
		return user_Profile;
	}

	public void setUser_Profile(User_Profile user_Profile) {
		this.user_Profile = user_Profile;
	}

	public List<Like> getLike() {
		return like;
	}

	public void setLike(List<Like> like) {
		this.like = like;
	}

	public List<Comment> getComment() {
		return comment;
	}

	public void setComment(List<Comment> comment) {
		this.comment = comment;
	}

	@Override
	public String toString() {
		return "Blog [blog_id=" + blog_id + ", user_id=" + user_id + ", blog_title=" + blog_title + ", blog=" + blog
				+ ", date_created=" + date_created + ", user_Profile=" + user_Profile + ", like=" + like + ", comment="
				+ comment + "]";
	}
}
