package com.Avega.demo;

public interface Communication {
	
	void call();
	void message();
	void chart();
}
