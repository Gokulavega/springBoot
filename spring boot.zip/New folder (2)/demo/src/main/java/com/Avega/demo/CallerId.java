package com.Avega.demo;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class CallerId {
	
	Communication communication;
	Communication communication1;

	public CallerId(@Qualifier("phone") Communication communication,
			@Qualifier("phone") Communication communication1) {
		this.communication = communication;
		this.communication1 = communication1;
		System.out.println("match" + (this.communication == this.communication1));
	}
	
	@PostConstruct
	public void init() {
		System.out.println("in post construct");
	}
	
	public void makeCall() {
		this.communication.call();
	}
	
	
}
