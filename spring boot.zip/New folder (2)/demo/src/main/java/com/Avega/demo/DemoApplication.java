package com.Avega.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication(scanBasePackages = {"com.Avega.demo","com.Avega.xyz"})
public class DemoApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext ctn = SpringApplication.run(DemoApplication.class, args);
		CallerId obj = ctn.getBean(CallerId.class);
		obj.makeCall();
	}

}
