package com.Avega.demo;

import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class Phone implements Communication{

	@Override
	public void call() {
		System.out.println("call through phone");
	}

	@Override
	public void message() {
		System.out.println("message through phone");
	}

	@Override
	public void chart() {
		System.out.println("chart through phone");
	}
}
