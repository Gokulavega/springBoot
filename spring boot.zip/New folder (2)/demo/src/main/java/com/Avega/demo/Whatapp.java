package com.Avega.demo;

import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component
@Primary
@Lazy
 class Whatapp implements Communication{

	@Override
	public void call() {
		System.out.println("call through whatapp");
	}

	@Override
	public void message() {
		System.out.println("message through whatapp");
	}

	@Override
	public void chart() {
		System.out.println("chart through whatapp");
	}
	
}
