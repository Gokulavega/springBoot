package com.avega.jpa.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.avega.jpa.entity.Employee;
import com.avega.jpa.entity.Role;
import com.avega.jpa.service.RoleService;

@Controller
public class RoleController {

	@Autowired
	RoleService roleService;
	
	@RequestMapping(value = "/role-details", method = RequestMethod.GET)
	public String getAllRoles(Model model) {
		model.addAttribute("listOfRoles", roleService.findAllRoles());
		return "role_details";
	}
	
	@RequestMapping(value = "/role-create", method = RequestMethod.GET)
	public String addRole(Model model) {
		model.addAttribute(new Role());
		return "create_role";
	}
	
	@RequestMapping(value = "/role-update", method = RequestMethod.GET)
	public String updateRole(@RequestParam String roleId, Model model) {
		Optional<Role> roleOptional = roleService.findByRoleId(roleId);
		if (roleOptional.isPresent())
			model.addAttribute(roleOptional.get());
		return "update_role";
	}
	
	@RequestMapping(value = "/role-save", method = RequestMethod.POST)
	public String saveRole(@ModelAttribute("role") Role role) {
		roleService.addRole(role);
		return "redirect:/role-details";
	}
	
	@RequestMapping(value = "/update-role-save", method = RequestMethod.POST)
	public String saveUpdateRole(@ModelAttribute("role") Role role) {
		roleService.updateRole(role);
		return "redirect:/role-details";
	}
	@RequestMapping(value = "/role-delete/{roleId}")
	public String deleteRole(@PathVariable String roleId) {
		Optional<Role> role = roleService.findByRoleId(roleId);
		if (role.isPresent())
			roleService.deleteRole(role.get());
		return "redirect:/role-details";
	}
	
	
	

}
