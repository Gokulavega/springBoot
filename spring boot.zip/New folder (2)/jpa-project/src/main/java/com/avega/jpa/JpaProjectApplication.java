package com.avega.jpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.context.ApplicationContext;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.avega.jpa.service.EmployeeService;
import com.avega.jpa.serviceImpl.EmployeeServiceImpl;

@SpringBootApplication (exclude = {SecurityAutoConfiguration.class})
@EnableJpaRepositories
public class JpaProjectApplication {

	public static void main(String[] args) {
		ApplicationContext ctn = SpringApplication.run(JpaProjectApplication.class, args);
//		EmployeeService ser = ctn.getBean(EmployeeServiceImpl.class);
//		ser.allocateRoleForEmployee("EMP001", "R001");
	}

}
