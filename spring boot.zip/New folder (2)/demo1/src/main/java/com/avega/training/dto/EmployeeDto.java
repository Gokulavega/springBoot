package com.avega.training.dto;

import java.time.LocalDate;

import javax.validation.constraints.NotNull;

public class EmployeeDto {
	
	@NotNull(message = "employee id cannot be null")
	private String employeeId;
	
	@NotNull(message = "employee name cannot be null")
	private String name;
	
	private LocalDate doj;

	public EmployeeDto() {
		
		
	}

	public EmployeeDto(@NotNull(message = "employee id cannot be null") String employeeId,
			@NotNull(message = "employee name cannot be null") String name, LocalDate doj) {
		super();
		this.employeeId = employeeId;
		this.name = name;
		this.doj = doj;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LocalDate getDoj() {
		return doj;
	}

	public void setDoj(LocalDate doj) {
		this.doj = doj;
	}

	@Override
	public String toString() {
		return "EmployeeDto [employeeId=" + employeeId + ", name=" + name + ", doj=" + doj + "]";
	}
	
	
}
