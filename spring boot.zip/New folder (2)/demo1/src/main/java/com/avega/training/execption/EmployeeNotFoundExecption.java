package com.avega.training.execption;

public class EmployeeNotFoundExecption extends Exception{
	
	private String errorMessage;

	public EmployeeNotFoundExecption(String message) {
		super();
		this.errorMessage = message;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	
	
}
