package com.avega.training.serviceimp;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.avega.training.dao.RoleDao;
import com.avega.training.model.Role;
import com.avega.training.service.RoleService;

@Service
public class RoleServiceImp implements RoleService{
	
	RoleDao dao;
	
	@Autowired
	public RoleServiceImp(RoleDao dao) {
		this.dao = dao;
	}

	@Override
	public List<Role> findAllRole() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}

	@Override
	public Optional<Role> findById(String RoleId) {
		// TODO Auto-generated method stub
		return dao.findById(RoleId);
	}

	@Override
	public Role addRole(Role role) {
		// TODO Auto-generated method stub
		return dao.save(role);
	}

	@Override
	public void updateRole(Role role) {
		Optional<Role> roles = dao.findById(role.getRoleId());
		if(roles.isPresent()) {
			roles.get().setRoleName(role.getRoleName());
			addRole(roles.get());
		}
	}

	@Override
	public void deleteRole(Role role) {
		dao.delete(role);
	}

}
