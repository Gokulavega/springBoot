package com.avega.training.model;


import java.time.LocalDate;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "employee")
public class Employee {
	
	@Id
	@Column(name = "employee_id")
	private String employeeId;
	
	@Column(name = "name")
	private String name;
	
	@Column(name = "doj")
	private LocalDate doj;
	
	@Column(name = "designation")
	private String designation;
	
	@ManyToOne
	@JoinColumn(name = "departmentId")
	private Department department;
	
	@JsonIgnore
	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(name = "employees_role",
	joinColumns = @JoinColumn(referencedColumnName = "employee_id"),
	inverseJoinColumns = @JoinColumn(referencedColumnName = "roleId"))
	private List<Role> roles;
	
	@ManyToMany()
	@JoinTable(name = "employees_skill",
	joinColumns = @JoinColumn(referencedColumnName = "employee_id"),
	inverseJoinColumns = @JoinColumn(referencedColumnName = "skillId"))
	private List<Skill> skills;

	public Employee() {
		
	}

	public Employee(String employeeId, String name, LocalDate doj, String designation, Department department,
			List<Role> roles, List<Skill> skills) {
		super();
		this.employeeId = employeeId;
		this.name = name;
		this.doj = doj;
		this.designation = designation;
		this.department = department;
		this.roles = roles;
		this.skills = skills;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LocalDate getDoj() {
		return doj;
	}

	public void setDoj(LocalDate doj) {
		this.doj = doj;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	public List<Role> getRoles() {
		return roles;
	}

	public void setRoles(List<Role> roles) {
		this.roles = roles;
	}

	public List<Skill> getSkills() {
		return skills;
	}

	public void setSkills(List<Skill> skills) {
		this.skills = skills;
	}

	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", name=" + name + ", doj=" + doj + ", designation=" + designation
				+ ", department=" + department + ", roles=" + roles + ", skills=" + skills + "]";
	}
	
}
