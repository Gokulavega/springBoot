package com.avega.training.controller;

import org.springframework.stereotype.Controller;

@Controller
public class EmployeeController {
	
//	@Autowired
//	EmployeeService dao;
//	
//	@InitBinder
//	public void employeeBinder(WebDataBinder webDataBinder) {
//		webDataBinder.registerCustomEditor(LocalDate.class, "doj", new LocalDateProperty());
//	}
//	
//	@RequestMapping("/employeelist")
//	public String employeelist(Model model) {
//		List<Employee> list = dao.findAllEmployee();
//		model.addAttribute("list", list);
//		return "employeelist";
//	}
//	
//	@RequestMapping("/employeeform")    
//    public String showform(Model model){    
//        model.addAttribute("command", new Employee());  
//        return "employeeform";   
//    }
//	
//	@RequestMapping(value="/save",method = RequestMethod.POST)    
//    public String save(@ModelAttribute("emp") Employee emp){    
//        dao.addEmployee(emp);   
//        return "redirect:/employeelist";
//    }
//	
//	@RequestMapping(value="/employeeeditform")    
//    public String edit(@RequestParam (required=false,name="employeeId")String employeeId, Model model){  
//        Optional<Employee> emp=dao.findByEmployeeId(employeeId);  
//        if(emp.isPresent()) {
//        	Employee e = emp.get();
//        	model.addAttribute("command", e); 
//        }
//        return "employeeeditform";    
//    }
//	
//	@RequestMapping(value="/editsave",method = RequestMethod.POST)    
//    public String editsave(@ModelAttribute("emp") Employee emp){  
//        dao.updateEmployee(emp);
//        return "redirect:/employeelist";    
//    }
//	
//	@RequestMapping(value="/deleteemp/{employeeId}",method = RequestMethod.GET)    
//    public String delete(@PathVariable String employeeId){  
//		Optional<Employee> emp = dao.findByEmployeeId(employeeId);
//        if(emp.isPresent())
//        	dao.deleteEmployee(emp.get());
//        return "redirect:/employeelist";    
//    }  
}
