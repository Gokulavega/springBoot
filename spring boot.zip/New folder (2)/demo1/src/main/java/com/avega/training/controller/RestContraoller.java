package com.avega.training.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.avega.training.dto.EmployeeDto;
import com.avega.training.execption.EmployeeNotFoundExecption;
import com.avega.training.model.Employee;
import com.avega.training.response.APIResponse;
import com.avega.training.service.EmployeeService;

@RestController
public class RestContraoller {
	
	@Autowired
	EmployeeService dao;
	
	@GetMapping("/employees")
	public ResponseEntity<APIResponse> getemployee(){
		List<Employee> employees = dao.findAllEmployee();
		
//		List<Employee> employees = new ArrayList<>();
		APIResponse response = new APIResponse();
		if(!employees.isEmpty()) {
			response.setMessage("successfull");
			response.setStatusCode(String.valueOf(HttpStatus.OK));
			response.setData(employees);
		} else {
			response.setMessage("employee list is empty");
			response.setStatusCode(String.valueOf(HttpStatus.NO_CONTENT));
		}
		return ResponseEntity.ok(response);
	}
	
	@PostMapping("/employee")
	public ResponseEntity<APIResponse> addEmployee(@RequestBody @Validated EmployeeDto employeeDto, BindingResult result){
		EmployeeDto eDto = new EmployeeDto();
		APIResponse response = new APIResponse();
		if(result.hasErrors()) {
			response.setStatusCode(String.valueOf(HttpStatus.NOT_ACCEPTABLE));
			response.setMessage("Invalid data");
			return ResponseEntity.badRequest().body(response);
		} else {
			Optional<Employee> data = dao.findByEmployeeId(employeeDto.getEmployeeId());
			if(data.isPresent()) {
				response.setStatusCode(String.valueOf(HttpStatus.ALREADY_REPORTED));
				response.setMessage("Employee already exist");
				return ResponseEntity.ok(response);
			} else {
				eDto = dao.addEmployee(employeeDto);
				response.setStatusCode(String.valueOf(HttpStatus.CREATED));
				response.setMessage("Succesufully");
				return ResponseEntity.ok(response);
			}
		}
	}
	
	@DeleteMapping("/employee/{id}")
	 public ResponseEntity<String> deleteEmployee (@PathVariable("id") String employeeId) throws EmployeeNotFoundExecption{  
		Employee emp = dao.findByEmployeeId(employeeId).orElseThrow(() -> new EmployeeNotFoundExecption(employeeId + " not found "));
	    	dao.deleteEmployee(emp);
	     	return  ResponseEntity.ok("succefully deleted");
	  }
	
	@PutMapping("/updateemployee/{id}")
	public ResponseEntity<APIResponse> updateEmployee(@PathVariable("id") String employeeId, @RequestBody @Validated EmployeeDto employeeDto, BindingResult result) throws EmployeeNotFoundExecption{
		APIResponse response = new APIResponse();
			Employee data = dao.findByEmployeeId(employeeId).orElseThrow(() -> new EmployeeNotFoundExecption(employeeId + " not found"));
				Employee emp = data;
				emp.setName(employeeDto.getName());
				emp.setDoj(employeeDto.getDoj());
				dao.updateEmployee(emp);
				response.setStatusCode(String.valueOf(HttpStatus.CREATED));
				response.setMessage("Succesufully");
				response.setData(emp);
			return ResponseEntity.ok(response);
	}
}
