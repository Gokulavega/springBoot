package com.avega.training.execption;

public class ApiError {
	
	private String errorMessage;

	public ApiError() {
		
	}

	public ApiError(String errorMessage) {
		super();
		this.errorMessage = errorMessage;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	
	
}
