package com.avega.training.service;

import java.util.List;
import java.util.Optional;

import com.avega.training.model.Role;

public interface RoleService {

	List<Role> findAllRole();

	Optional<Role> findById(String RoleId);

	Role addRole(Role role);

	void updateRole(Role role);

	void deleteRole(Role role);
}
