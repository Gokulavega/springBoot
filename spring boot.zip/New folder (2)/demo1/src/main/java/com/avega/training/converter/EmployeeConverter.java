package com.avega.training.converter;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.avega.training.dto.EmployeeDto;
import com.avega.training.model.Employee;

@Component
public class EmployeeConverter {
	
	public Employee converterToEntity(EmployeeDto empDto) {
		Employee emp = new Employee();
		BeanUtils.copyProperties(empDto, emp);
		return emp;
	}
	
	public EmployeeDto converterToDto(Employee employee) {
		EmployeeDto empDto = new EmployeeDto();
		BeanUtils.copyProperties(employee, empDto);
		return empDto;
	}
}
