package com.avega.training.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Department")
public class Department {
	
	@Id
	@Column(name = "department_id")
	private String departmentId;
	
	@Column(name = "name")
	private String name;
	
	@Column(name = "head_of_department")
	private String hod;
	
	@OneToMany(mappedBy = "department")
	private List<Employee> employees;

	public Department() {
		
	}

	public Department(String departmentId, String name, String hod, List<Employee> employees) {
		super();
		this.departmentId = departmentId;
		this.name = name;
		this.hod = hod;
		this.employees = employees;
	}

	public String getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(String departmentId) {
		this.departmentId = departmentId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getHod() {
		return hod;
	}

	public void setHod(String hod) {
		this.hod = hod;
	}

	public List<Employee> getEmployees() {
		return employees;
	}

	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}

	@Override
	public String toString() {
		return "Department [departmentId=" + departmentId + ", name=" + name + ", hod=" + hod + ", employees="
				+ employees + "]";
	}
	
}
