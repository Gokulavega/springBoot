package com.avega.training.execption;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

@ControllerAdvice
public class GlobalExecptionHandler {
	
	@ExceptionHandler({EmployeeNotFoundExecption.class})
	public ResponseEntity<ApiError> handlerEmployeeNotFoundException(EmployeeNotFoundExecption ex, WebRequest webRequest){
		HttpHeaders httpHeaders = new HttpHeaders();
		HttpStatus httpStatus = HttpStatus.NOT_FOUND;
		return new ResponseEntity<>(new ApiError(ex.getErrorMessage()), httpHeaders, httpStatus);
	}
}
