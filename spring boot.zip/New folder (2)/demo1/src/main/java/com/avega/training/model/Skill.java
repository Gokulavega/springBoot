package com.avega.training.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Skill")
public class Skill {
	
	@Id
	private String skillId;
	
	@Column(name = "description")
	private String description;
	
	@ManyToMany(mappedBy = "skills")
	private List<Employee> employees;

	public Skill() {
		
	}

	public Skill(String skillId, String description, List<Employee> employees) {
		super();
		this.skillId = skillId;
		this.description = description;
		this.employees = employees;
	}

	public String getSkillId() {
		return skillId;
	}

	public void setSkillId(String skillId) {
		this.skillId = skillId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public List<Employee> getEmployees() {
		return employees;
	}

	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}

	@Override
	public String toString() {
		return "Skill [skillId=" + skillId + ", description=" + description + ", employees=" + employees + "]";
	}
	
}
