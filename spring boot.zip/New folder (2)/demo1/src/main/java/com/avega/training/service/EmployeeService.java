package com.avega.training.service;

import java.util.List;
import java.util.Optional;

import com.avega.training.dto.EmployeeDto;
import com.avega.training.model.Employee;

public interface EmployeeService {
	
	List<Employee> findAllEmployee();
	
	Optional<Employee> findByEmployeeId(String employeeId);
	
	EmployeeDto addEmployee(EmployeeDto employeeDto);
	
	void updateEmployee(Employee employee);
	
	void deleteEmployee(Employee employee);
	
	void allocationRoleToEmployee(String roleId, String employeeId);
	
}
