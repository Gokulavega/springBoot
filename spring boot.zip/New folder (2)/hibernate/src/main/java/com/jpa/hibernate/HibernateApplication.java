package com.jpa.hibernate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.ApplicationContext;

import com.avega.training.service.EmployeeService;
import com.avega.training.serviceimp.EmployeeServiceImp;

@SpringBootApplication(scanBasePackages = {"com.jpa.hibernate","com.avega.training"})
@EntityScan("com.avega.training")
public class HibernateApplication {

	public static void main(String[] args) {
		ApplicationContext ctn = SpringApplication.run(HibernateApplication.class, args);
		EmployeeService emp = ctn.getBean(EmployeeServiceImp.class);
		
		System.out.println(emp.findAllEmployee());
	}

}
