package com.avega.training.service;

import java.util.List;

import com.avega.training.model.Allocation;

public interface AllocationService {
	
	List<Allocation> findAllAllocation();
	Allocation findAllocation(String id);
	boolean createAllocation(Allocation allocation);
	boolean removeAllocation(String id);
	boolean editAllocation(Allocation allocation);
}
