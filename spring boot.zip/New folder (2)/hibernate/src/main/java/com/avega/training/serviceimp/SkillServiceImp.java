package com.avega.training.serviceimp;

import java.util.List;
import java.util.logging.Logger;

import com.avega.training.dao.SkillDao;
import com.avega.training.model.Skill;
import com.avega.training.service.SkillService;

public class SkillServiceImp implements SkillService{
	
	static Logger logger = Logger.getLogger(SkillServiceImp.class.getName());
	
	SkillDao dao = null;

	@Override
	public List<Skill> findAllSkill() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Skill findSkill(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean createSkill(Skill skill) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean removeSkill(String id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean editSkill(Skill skill) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<Skill> loadExcelToDB(String excelFilePath) {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	
	
}
