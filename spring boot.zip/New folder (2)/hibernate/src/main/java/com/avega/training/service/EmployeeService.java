package com.avega.training.service;

import java.util.List;

import com.avega.training.model.Employee;

public interface EmployeeService {
	
	List<Employee> findAllEmployee();
	
}
