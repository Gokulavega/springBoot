package com.avega.training.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.avega.training.model.Allocation;

@Repository
public interface AllocationDao extends JpaRepository<Allocation, String>{
	
}
