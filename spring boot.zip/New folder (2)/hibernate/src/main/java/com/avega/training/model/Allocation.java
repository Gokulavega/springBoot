package com.avega.training.model;



import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
@Entity
@Table(name = "allocation")
public class Allocation {
	
	@Id
	private String allocationId;
	
	@ManyToOne
	@JoinTable(name = "employee_allocations",
	joinColumns = @JoinColumn(referencedColumnName = "allocationId"),
	inverseJoinColumns = @JoinColumn(referencedColumnName = "employee_id"))
	private Employee employee;
	
	@ManyToOne
	private Training training;
	
	@OneToOne
	private Employee allocatedBy;
	
	private Date allocationDate;
	
}
