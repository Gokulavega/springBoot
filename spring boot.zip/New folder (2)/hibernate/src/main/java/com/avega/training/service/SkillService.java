package com.avega.training.service;

import java.util.List;

import com.avega.training.model.Skill;

public interface SkillService {
	
	List<Skill> findAllSkill();
	Skill findSkill(String id);
	boolean createSkill(Skill skill);
	boolean removeSkill(String id);
	boolean editSkill(Skill skill);
	List<Skill> loadExcelToDB(String excelFilePath);
}
