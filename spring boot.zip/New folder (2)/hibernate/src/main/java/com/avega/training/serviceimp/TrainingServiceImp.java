package com.avega.training.serviceimp;

import java.io.IOException;
import java.sql.Date;
import java.util.List;
import java.util.logging.Logger;

import com.avega.training.dao.TrainingDao;
import com.avega.training.model.Training;
import com.avega.training.service.TrainingService;

public class TrainingServiceImp implements TrainingService{
	
	static Logger logger = Logger.getLogger(TrainingServiceImp.class.getName());
	TrainingDao dao = null;
	@Override
	public List<Training> findAllTraining() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public Training findTraining(String id) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public boolean createTraining(Training training) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public boolean removeTraining(String id) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public boolean editTraining(Training training) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public void loadDBToExcel(Date date) throws IOException {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void findTrainingOfThisMonth(Date date) {
		// TODO Auto-generated method stub
		
	}

	
}
