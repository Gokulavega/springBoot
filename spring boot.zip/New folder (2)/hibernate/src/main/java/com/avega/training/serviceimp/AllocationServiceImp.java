package com.avega.training.serviceimp;

import java.util.List;

import com.avega.training.model.Allocation;
import com.avega.training.service.AllocationService;

public class AllocationServiceImp implements AllocationService{

	@Override
	public List<Allocation> findAllAllocation() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Allocation findAllocation(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean createAllocation(Allocation allocation) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean removeAllocation(String id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean editAllocation(Allocation allocation) {
		// TODO Auto-generated method stub
		return false;
	}
	
	
}
