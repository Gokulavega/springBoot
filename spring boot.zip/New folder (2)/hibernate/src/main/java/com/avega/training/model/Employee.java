package com.avega.training.model;


import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
@Entity
@Table(name = "employee")
public class Employee {
	
	@Id
	@Column(name = "employee_id")
	private String employeeId;
	
	@Column(name = "name")
	private String name;
	
	@Column(name = "doj")
	private Date doj;
	
	@Column(name = "designation")
	private String designation;
	
	@Column(name = "department")
	private String department;
	
	@ManyToMany
	@JoinTable(name = "employee_skill",
	joinColumns = @JoinColumn(referencedColumnName = "employee_id"),
	inverseJoinColumns = @JoinColumn(referencedColumnName = "skillId"))
	private Set<Skill> skills;
	
	
	@OneToMany(mappedBy = "employee")
	private List<Allocation> trainings;
	
	
}
