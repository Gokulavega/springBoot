package com.avega.training.serviceimp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.avega.training.dao.EmployeeDao;
import com.avega.training.model.Employee;
import com.avega.training.service.EmployeeService;

@Service
public class EmployeeServiceImp implements EmployeeService{
	
	
	EmployeeDao dao;
	
	@Autowired
	public EmployeeServiceImp(EmployeeDao dao) {
		this.dao = dao;
	}

	@Override
	public List<Employee> findAllEmployee() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}

	
}
