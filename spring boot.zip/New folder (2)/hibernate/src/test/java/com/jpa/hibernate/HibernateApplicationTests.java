package com.jpa.hibernate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HibernateApplicationTests {

	@Test
	void contextLoads() {
	}

}
